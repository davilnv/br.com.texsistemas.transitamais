package br.com.texsistemas.transitamais.pontoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PontoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
